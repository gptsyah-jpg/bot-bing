/**
 * Telegram Web App - Slider Puzzle Captcha
 * =========================================
 * A VMOSCloud-style slider puzzle captcha with:
 * - Random pattern generation
 * - Puzzle piece cutout
 * - Horizontal drag slider
 * - Success/fail animations
 * - Telegram WebApp integration
 */

// ─── Telegram Web App Init ───────────────────────────────────────────────────
const tg = window.Telegram?.WebApp;

// Expand Web App to full height
if (tg) {
  tg.expand();
  tg.ready();
}

// ─── DOM Elements ────────────────────────────────────────────────────────────
const loadingScreen = document.getElementById('loading-screen');
const appContainer = document.getElementById('app');
const captchaCanvas = document.getElementById('captcha-canvas');
const puzzlePiece = document.getElementById('puzzle-piece');
const sliderThumb = document.getElementById('slider-thumb');
const sliderFill = document.getElementById('slider-fill');
const refreshBtn = document.getElementById('refresh-btn');
const statusMessage = document.getElementById('status-message');
const successOverlay = document.getElementById('success-overlay');
const particlesContainer = document.getElementById('particles');

const ctx = captchaCanvas.getContext('2d');
const pieceCtx = puzzlePiece.getContext('2d');

// ─── Configuration ───────────────────────────────────────────────────────────
const CONFIG = {
  canvasWidth: 280,
  canvasHeight: 160,
  pieceSize: 44,        // Puzzle piece dimensions
  tolerance: 5,         // ±5px tolerance for success
  maxAttempts: 5,       // Max attempts before lockout
};

// ─── State ───────────────────────────────────────────────────────────────────
let state = {
  targetX: 0,           // Where the puzzle hole is (X position)
  targetY: 0,           // Where the puzzle hole is (Y position)
  currentX: 0,          // Current slider/piece position
  isDragging: false,
  startX: 0,
  attempts: 0,
  solved: false,
  locked: false,
};

// ─── Initialize ──────────────────────────────────────────────────────────────

/**
 * Boot sequence: show loading, then reveal app
 */
function init() {
  // Create floating particles
  createParticles();

  // Simulate loading (asset preparation)
  setTimeout(() => {
    loadingScreen.classList.add('hidden');
    appContainer.classList.remove('hidden');
    generateCaptcha();
  }, 1200);
}

// ─── Particle Effects ────────────────────────────────────────────────────────

function createParticles() {
  for (let i = 0; i < 15; i++) {
    const particle = document.createElement('div');
    particle.className = 'particle';
    particle.style.left = Math.random() * 100 + '%';
    particle.style.width = (3 + Math.random() * 5) + 'px';
    particle.style.height = particle.style.width;
    particle.style.animationDuration = (8 + Math.random() * 12) + 's';
    particle.style.animationDelay = Math.random() * 5 + 's';
    particlesContainer.appendChild(particle);
  }
}

// ─── Captcha Generation ──────────────────────────────────────────────────────

/**
 * Generate a new captcha puzzle with random background and cutout position
 */
function generateCaptcha() {
  if (state.locked) return;

  // Reset state
  state.targetX = 60 + Math.floor(Math.random() * (CONFIG.canvasWidth - CONFIG.pieceSize - 100));
  state.targetY = 20 + Math.floor(Math.random() * (CONFIG.canvasHeight - CONFIG.pieceSize - 40));
  state.currentX = 0;
  state.solved = false;

  // Reset slider position
  sliderThumb.style.left = '2px';
  sliderFill.style.width = '0px';

  // Clear status
  statusMessage.className = 'status-message';
  statusMessage.style.display = 'none';

  // Draw background pattern
  drawBackground();

  // Draw puzzle cutout on main canvas
  drawPuzzleHole();

  // Draw puzzle piece on separate canvas
  drawPuzzlePieceCanvas();

  // Reset piece position
  puzzlePiece.style.left = '0px';
  puzzlePiece.style.top = state.targetY + 'px';
}

/**
 * Draw a colorful random background pattern
 */
function drawBackground() {
  // Gradient background
  const gradient = ctx.createLinearGradient(0, 0, CONFIG.canvasWidth, CONFIG.canvasHeight);
  const hue1 = Math.random() * 360;
  const hue2 = (hue1 + 40 + Math.random() * 60) % 360;
  gradient.addColorStop(0, `hsl(${hue1}, 60%, 70%)`);
  gradient.addColorStop(1, `hsl(${hue2}, 60%, 65%)`);
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, CONFIG.canvasWidth, CONFIG.canvasHeight);

  // Random shapes for visual complexity
  for (let i = 0; i < 12; i++) {
    ctx.beginPath();
    const x = Math.random() * CONFIG.canvasWidth;
    const y = Math.random() * CONFIG.canvasHeight;
    const radius = 10 + Math.random() * 30;
    ctx.arc(x, y, radius, 0, Math.PI * 2);
    ctx.fillStyle = `hsla(${Math.random() * 360}, 50%, 60%, 0.3)`;
    ctx.fill();
  }

  // Add some lines for texture
  for (let i = 0; i < 5; i++) {
    ctx.beginPath();
    ctx.moveTo(Math.random() * CONFIG.canvasWidth, Math.random() * CONFIG.canvasHeight);
    ctx.lineTo(Math.random() * CONFIG.canvasWidth, Math.random() * CONFIG.canvasHeight);
    ctx.strokeStyle = `rgba(255, 255, 255, 0.2)`;
    ctx.lineWidth = 1 + Math.random() * 2;
    ctx.stroke();
  }
}

/**
 * Draw the puzzle piece path (with knob)
 */
function getPuzzlePath(ctx, x, y, size) {
  const knobSize = size * 0.25;
  ctx.beginPath();
  ctx.moveTo(x, y);

  // Top edge with knob
  ctx.lineTo(x + size * 0.35, y);
  ctx.arc(x + size * 0.5, y, knobSize, Math.PI, 0, false);
  ctx.lineTo(x + size, y);

  // Right edge with knob
  ctx.lineTo(x + size, y + size * 0.35);
  ctx.arc(x + size, y + size * 0.5, knobSize, -Math.PI / 2, Math.PI / 2, false);
  ctx.lineTo(x + size, y + size);

  // Bottom edge
  ctx.lineTo(x, y + size);

  // Left edge
  ctx.lineTo(x, y);
  ctx.closePath();
}

/**
 * Draw the puzzle hole (dark cutout on main canvas)
 */
function drawPuzzleHole() {
  const { targetX, targetY } = state;
  const size = CONFIG.pieceSize;

  // Draw shadow/hole
  ctx.save();
  getPuzzlePath(ctx, targetX, targetY, size);
  ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
  ctx.fill();

  // Inner shadow effect
  ctx.strokeStyle = 'rgba(0, 0, 0, 0.3)';
  ctx.lineWidth = 1.5;
  ctx.stroke();
  ctx.restore();
}

/**
 * Draw the draggable puzzle piece on its own canvas
 */
function drawPuzzlePieceCanvas() {
  const size = CONFIG.pieceSize;
  const knobSize = size * 0.25;
  const totalWidth = size + knobSize;
  const totalHeight = size + knobSize;

  puzzlePiece.width = totalWidth;
  puzzlePiece.height = totalHeight;
  puzzlePiece.style.width = totalWidth + 'px';
  puzzlePiece.style.height = totalHeight + 'px';

  pieceCtx.clearRect(0, 0, totalWidth, totalHeight);

  // Clip and draw the piece from the main canvas image data
  pieceCtx.save();

  // Use the same path but offset to 0,0 for the piece canvas
  const offsetX = 0;
  const offsetY = knobSize;

  getPuzzlePath(pieceCtx, offsetX, state.targetY > 0 ? 0 : 0, size);
  pieceCtx.clip();

  // Draw the corresponding area from the background
  // Re-create the background on piece
  const tempCanvas = document.createElement('canvas');
  tempCanvas.width = CONFIG.canvasWidth;
  tempCanvas.height = CONFIG.canvasHeight;
  const tempCtx = tempCanvas.getContext('2d');

  // Copy current canvas (before hole was drawn)
  // We'll regenerate the background portion
  const bgGradient = tempCtx.createLinearGradient(0, 0, CONFIG.canvasWidth, CONFIG.canvasHeight);
  bgGradient.addColorStop(0, '#88c0d0');
  bgGradient.addColorStop(1, '#81a1c1');
  tempCtx.fillStyle = bgGradient;
  tempCtx.fillRect(0, 0, CONFIG.canvasWidth, CONFIG.canvasHeight);

  // Get image data from the actual canvas
  pieceCtx.drawImage(captchaCanvas, state.targetX, state.targetY, size, size, offsetX, 0, size, size);

  pieceCtx.restore();

  // Draw border around piece
  getPuzzlePath(pieceCtx, offsetX, 0, size);
  pieceCtx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
  pieceCtx.lineWidth = 2;
  pieceCtx.stroke();

  // Add shadow effect
  pieceCtx.shadowColor = 'rgba(0, 0, 0, 0.5)';
  pieceCtx.shadowBlur = 4;

  // Position the piece canvas
  puzzlePiece.style.top = state.targetY + 'px';
  puzzlePiece.style.left = '0px';
}

// ─── Slider Interaction ──────────────────────────────────────────────────────

const sliderTrack = document.querySelector('.slider-track');
const trackWidth = 280; // Match slider width
const thumbWidth = 40;
const maxSlide = trackWidth - thumbWidth - 4; // Account for padding

/**
 * Start dragging
 */
function onDragStart(e) {
  if (state.solved || state.locked) return;
  e.preventDefault();

  state.isDragging = true;
  state.startX = getClientX(e) - state.currentX;
  sliderThumb.style.transition = 'none';
  sliderFill.style.transition = 'none';
  puzzlePiece.style.transition = 'none';
}

/**
 * During drag
 */
function onDragMove(e) {
  if (!state.isDragging) return;
  e.preventDefault();

  const clientX = getClientX(e);
  let newX = clientX - state.startX;

  // Clamp to track bounds
  newX = Math.max(0, Math.min(newX, maxSlide));

  state.currentX = newX;

  // Update slider position
  sliderThumb.style.left = (newX + 2) + 'px';
  sliderFill.style.width = (newX + thumbWidth / 2) + 'px';

  // Move puzzle piece proportionally
  const pieceMaxX = CONFIG.canvasWidth - CONFIG.pieceSize;
  const pieceX = (newX / maxSlide) * pieceMaxX;
  puzzlePiece.style.left = pieceX + 'px';
}

/**
 * End drag - check if puzzle is solved
 */
function onDragEnd(e) {
  if (!state.isDragging) return;
  state.isDragging = false;

  // Calculate piece position
  const pieceMaxX = CONFIG.canvasWidth - CONFIG.pieceSize;
  const pieceX = (state.currentX / maxSlide) * pieceMaxX;

  // Check if within tolerance
  const diff = Math.abs(pieceX - state.targetX);

  if (diff <= CONFIG.tolerance) {
    onSuccess();
  } else {
    onFail();
  }
}

/**
 * Get clientX from mouse or touch event
 */
function getClientX(e) {
  if (e.touches && e.touches.length > 0) {
    return e.touches[0].clientX;
  }
  return e.clientX;
}

// ─── Event Listeners ─────────────────────────────────────────────────────────

// Mouse events
sliderThumb.addEventListener('mousedown', onDragStart);
document.addEventListener('mousemove', onDragMove);
document.addEventListener('mouseup', onDragEnd);

// Touch events (mobile/Android)
sliderThumb.addEventListener('touchstart', onDragStart, { passive: false });
document.addEventListener('touchmove', onDragMove, { passive: false });
document.addEventListener('touchend', onDragEnd);

// Refresh button
refreshBtn.addEventListener('click', () => {
  refreshBtn.style.transform = 'rotate(360deg)';
  setTimeout(() => {
    refreshBtn.style.transform = '';
    generateCaptcha();
  }, 300);
});

// ─── Success Handler ─────────────────────────────────────────────────────────

function onSuccess() {
  state.solved = true;

  // Show success status
  showStatus('✓ Puzzle solved!', 'success');

  // Animate slider to green
  sliderFill.style.background = 'linear-gradient(90deg, #66bb6a, #43a047)';
  sliderThumb.style.boxShadow = '0 2px 8px rgba(0,0,0,0.15), 0 0 0 3px #43a047';

  // Show success overlay after brief delay
  setTimeout(() => {
    successOverlay.classList.remove('hidden');
  }, 600);

  // Send data to Telegram and close
  setTimeout(() => {
    if (tg) {
      tg.sendData('captcha_success');
      // Close after a brief moment
      setTimeout(() => {
        tg.close();
      }, 1000);
    }
  }, 1500);
}

// ─── Fail Handler ────────────────────────────────────────────────────────────

function onFail() {
  state.attempts++;

  if (state.attempts >= CONFIG.maxAttempts) {
    state.locked = true;
    showStatus('Too many attempts. Please try again later.', 'error');
    return;
  }

  // Show error
  showStatus(`Incorrect. ${CONFIG.maxAttempts - state.attempts} attempts left.`, 'error');

  // Shake animation
  const card = document.querySelector('.card');
  card.classList.add('shake');
  setTimeout(() => card.classList.remove('shake'), 500);

  // Reset slider with animation
  sliderThumb.style.transition = 'left 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
  sliderFill.style.transition = 'width 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
  puzzlePiece.style.transition = 'left 0.4s cubic-bezier(0.25, 0.46, 0.45, 0.94)';

  sliderThumb.style.left = '2px';
  sliderFill.style.width = '0px';
  puzzlePiece.style.left = '0px';
  state.currentX = 0;

  // Generate new captcha after fail
  setTimeout(() => generateCaptcha(), 800);
}

// ─── Status Display ──────────────────────────────────────────────────────────

function showStatus(message, type) {
  statusMessage.textContent = message;
  statusMessage.className = `status-message ${type}`;
  statusMessage.style.display = 'block';
}

// ─── Start ───────────────────────────────────────────────────────────────────
init();
