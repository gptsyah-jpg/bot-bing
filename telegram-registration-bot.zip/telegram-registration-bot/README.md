# 🤖 Telegram Registration Bot + Web App

A production-ready Telegram bot with a premium Web App verification page featuring a slider puzzle captcha, email collection, OTP validation, and secure password creation.

## ✨ Features

- **Telegram Bot** - Full registration flow with state management
- **Web App Captcha** - VMOSCloud-style slider puzzle verification
- **Premium UI** - White + yellow luxury fintech theme with glassmorphism
- **Security** - bcrypt password hashing, anti-spam, session management
- **Mobile-First** - Optimized for Telegram Android/iOS

## 📁 Project Structure

```
project/
├── bot.js           # Telegram bot (Telegraf)
├── server.js        # Express server for Web App
├── package.json     # Dependencies
├── .env.example     # Environment template
├── README.md        # This file
└── public/
    ├── index.html   # Web App page
    ├── style.css    # Premium styles
    └── script.js    # Captcha logic
```

## 🚀 Quick Start

### Prerequisites

- Node.js 18+
- Telegram Bot Token (from [@BotFather](https://t.me/BotFather))

### Installation

```bash
# Clone or download the project
cd telegram-registration-bot

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Edit .env with your bot token
nano .env
```

### Configure `.env`

```env
BOT_TOKEN=your_bot_token_here
WEBAPP_URL=https://your-project.vercel.app
PORT=3000
```

### Run Locally

```bash
# Start both bot and server
npm run dev

# Or separately:
npm run bot      # Start bot only
npm run server   # Start server only
```

## 🔧 Setup Guide

### 1. Create Telegram Bot

1. Open Telegram and search for `@BotFather`
2. Send `/newbot`
3. Choose a name and username
4. Copy the token to your `.env` file

### 2. Configure Web App URL

1. In BotFather, send `/mybots` → Select your bot → Bot Settings → Menu Button
2. Or use `/setmenubutton` to set the Web App URL
3. The Web App URL should point to where your `public/` folder is hosted

### 3. Deploy Web App to Vercel

```bash
# Install Vercel CLI
npm install -g vercel

# Deploy the public folder
cd public
vercel --prod
```

Or use the Vercel dashboard:
1. Go to [vercel.com](https://vercel.com)
2. Import your project
3. Set the root directory to `public/`
4. Deploy

After deploying, copy the URL and set it as `WEBAPP_URL` in `.env`.

### 4. Deploy Bot to Render

1. Go to [render.com](https://render.com)
2. Create a new Web Service
3. Connect your GitHub repository
4. Set build command: `npm install`
5. Set start command: `node bot.js`
6. Add environment variables (`BOT_TOKEN`, `WEBAPP_URL`)

### 5. Alternative: Deploy Everything Together

For a unified deployment (bot + web app on same server):

```bash
# Start both services
node server.js &  # Serves web app
node bot.js       # Runs the bot
```

Or use the combined `npm run dev` command.

## 📱 Registration Flow

1. User sends `/start`
2. Bot asks for email
3. User enters valid email
4. Bot shows "Verify Human" Web App button
5. User opens Web App → solves slider puzzle
6. On success → bot sends OTP (displayed in demo mode)
7. User enters 6-digit OTP
8. Bot asks for password (8+ chars)
9. Password is hashed with bcrypt
10. Registration complete! 🎉

## 🔒 Security Features

- **Email validation** - RFC-compliant regex check
- **Anti-spam** - 3-second cooldown between commands
- **Session isolation** - Per-user state management
- **OTP expiry** - 5-minute timeout
- **bcrypt hashing** - Passwords never stored in plaintext
- **Message deletion** - Password messages auto-deleted
- **Max attempts** - Captcha locks after 5 failed attempts

## 🎨 Web App UI

- White + Yellow premium theme
- Glassmorphism card design
- Animated floating particles
- Smooth slider physics
- Success checkmark animation
- Mobile-optimized layout
- Android Telegram compatible

## 🛠 Commands

| Command | Description |
|---------|-------------|
| `/start` | Begin registration |
| `/restart` | Reset and start over |
| `/status` | Check registration progress |

## ⚙️ Environment Variables

| Variable | Description | Required |
|----------|-------------|----------|
| `BOT_TOKEN` | Telegram bot token from BotFather | ✅ |
| `WEBAPP_URL` | Deployed Web App URL | ✅ |
| `PORT` | Express server port (default: 3000) | ❌ |
| `OTP_SECRET` | Secret for OTP generation | ❌ |

## 📝 Notes

- **Demo Mode**: OTP is displayed in the bot message for testing. In production, integrate with an email service (SendGrid, Mailgun, etc.)
- **Session Storage**: Uses in-memory Map. For production, use Redis or a database.
- **HTTPS Required**: Telegram Web Apps require HTTPS. Use a reverse proxy or deploy to a platform that provides it.

## 📄 License

MIT
